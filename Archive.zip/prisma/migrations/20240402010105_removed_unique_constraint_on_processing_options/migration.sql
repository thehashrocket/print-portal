-- DropIndex
DROP INDEX "ProcessingOptions_orderId_key";

-- DropIndex
DROP INDEX "ProcessingOptions_workOrderId_key";
