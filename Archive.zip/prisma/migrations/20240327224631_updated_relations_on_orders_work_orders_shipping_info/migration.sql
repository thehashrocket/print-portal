/*
  Warnings:

  - You are about to drop the column `shippingInfoId` on the `Order` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Order" DROP COLUMN "shippingInfoId";
