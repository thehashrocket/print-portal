-- AlterTable
ALTER TABLE "OrderItem" ADD COLUMN     "cutting" TEXT,
ADD COLUMN     "drilling" TEXT,
ADD COLUMN     "folding" TEXT,
ADD COLUMN     "other" TEXT;
