import React from 'react';

const DashboardPage: React.FC = () => {
    return (
        <div>
            <h1>Dashboard Page</h1>
            {/* Add your dashboard content here */}
        </div>
    );
};

export default DashboardPage;